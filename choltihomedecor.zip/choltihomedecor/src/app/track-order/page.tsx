import type { Metadata } from "next";
import Header from "@/components/Header";
import { CTA, Footer, FloatingWA } from "@/components/Closing";
import CartDrawer from "@/components/CartDrawer";
import { getCategories } from "@/lib/catalog-db";
import TrackView from "./TrackView";

export const metadata: Metadata = {
  title: "Track Order - Cholti",
  description: "Track your order on WhatsApp. Delivery in 2-4 days, cash on delivery.",
};

export default async function TrackPage() {
  return (
    <>
      <Header categories={await getCategories()} />
      <TrackView />
      <CTA />
      <Footer />
      <FloatingWA />
      <CartDrawer />
    </>
  );
}
