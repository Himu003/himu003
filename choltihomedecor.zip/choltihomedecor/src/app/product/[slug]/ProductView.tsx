"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { ShoppingCart, Banknote, Truck, RefreshCcw } from "lucide-react";
import Header from "@/components/Header";
import ProductCard from "@/components/ProductCard";
import { Footer, FloatingWA } from "@/components/Closing";
import CartDrawer from "@/components/CartDrawer";
import ProductReviews from "@/components/ProductReviews";
import { FABRICS } from "@/lib/data";
import type { Product } from "@/lib/data";
import type { ShopCategory, ShopFabric, ShopSize, ShopColor } from "@/lib/catalog-db";
import { useShop } from "@/lib/store";
import { useLang } from "@/lib/lang";

export default function ProductView({ product, related, categories, fabrics, sizes, colors }: { product: Product; related: Product[]; categories?: ShopCategory[]; fabrics?: ShopFabric[]; sizes?: ShopSize[]; colors?: ShopColor[] }) {
  const { t } = useLang();
  const p = product;
  const { addToCart, setCartOpen } = useShop();
  const fabricNames = p.fabricIds === undefined
    ? (fabrics === undefined ? FABRICS : fabrics.map((f) => f.name))
    : (fabrics ?? []).filter((f) => p.fabricIds!.includes(f.id)).map((f) => f.name);
  const sizeNames = p.sizeIds === undefined
    ? (sizes === undefined ? ["5-seater"] : sizes.map((s) => s.name))
    : (sizes ?? []).filter((s) => p.sizeIds!.includes(s.id)).map((s) => s.name);
  const colorList = p.colorIds === undefined
    ? (colors === undefined ? [{ id: "terracotta", name: "Terracotta", hex: "#BC4621" }] : colors)
    : (colors ?? []).filter((c) => p.colorIds!.includes(c.id));
  const [fabric, setFabric] = useState(fabricNames[0] ?? "");
  const [size, setSize] = useState(sizeNames[0] ?? "");
  const [color, setColor] = useState(colorList[0]?.name ?? "");
  const variant = [fabric, size, color].filter(Boolean).join(" / ") || "Standard";
  const [qty, setQty] = useState(1);
  const [img, setImg] = useState(0);

  const gallery = p.imgs?.length ? p.imgs : [p.img];

  return (
    <>
      <Header categories={categories} />
      <main className="max-w-[1180px] mx-auto px-5">
        <Link href="/" className="text-[17px] text-muted inline-block mt-4">{t.back}</Link>
        <div className="grid md:grid-cols-2 gap-7 py-7">
          <div className="min-w-0">
            <div className="relative w-full h-[280px] md:h-[480px]">
              <Image src={gallery[img % gallery.length]} alt={p.name} fill className="object-cover rounded-[20px] border border-line" sizes="(max-width:768px)100vw,50vw" priority />
            </div>
            <div className="flex gap-2.5 mt-2.5 overflow-x-auto pb-1">{gallery.map((im, i) => (
              <button key={i} onClick={() => setImg(i)} className={`relative w-20 h-20 shrink-0 rounded-xl overflow-hidden border ${i === img ? "outline outline-2 outline-gold" : "border-line"}`}>
                <Image src={im} alt="thumb" fill className="object-cover" sizes="80px" />
              </button>
            ))}</div>
          </div>
          <div className="min-w-0">
            <div className="eyebrow">{p.cat}</div>
            <h1 className="font-serif text-[24px] md:text-[30px] my-2">{p.name}</h1>
            <div className="text-[17px] text-muted"><span className="stars">★★★★★</span> {p.rating}</div>
            <div className="flex gap-2.5 items-center my-3"><span className="line-through text-muted">৳{p.old.toLocaleString()}</span><b className="text-[22px] md:text-[26px] text-clay">৳{p.now.toLocaleString()}</b><span className="bg-clay-light text-clay dark:bg-clay dark:text-white rounded-full px-2.5 py-1 text-sm md:text-base font-extrabold">Save ৳{(p.old - p.now).toLocaleString()}</span></div>
            {fabricNames.length > 0 && (
            <div><b className="text-base">{t.fabric}</b><div className="flex gap-2 flex-wrap my-2">{fabricNames.map((f) => <button key={f} onClick={() => setFabric(f)} className={`border rounded-full px-3.5 py-2 text-base font-bold ${f === fabric ? "border-clay bg-clay-light text-clay dark:bg-clay dark:text-white" : "border-line bg-paper"}`}>{f}{f === fabric ? " ✓" : ""}</button>)}</div></div>
            )}
            {sizeNames.length > 0 && (
            <div><b className="text-base">{t.size}</b><div className="flex gap-2 flex-wrap my-2">{sizeNames.map((s) => <button key={s} onClick={() => setSize(s)} className={`border rounded-full px-3.5 py-2 text-base font-bold ${s === size ? "border-clay bg-clay-light text-clay dark:bg-clay dark:text-white" : "border-line bg-paper"}`}>{s}</button>)}</div></div>
            )}
            {colorList.length > 0 && (
            <div><b className="text-base">{t.color}</b><div className="flex gap-2 my-2">{colorList.map(({ id, name: n, hex: c }) => <button key={id} title={n} onClick={() => setColor(n)} className={`w-8 h-8 rounded-full border-2 border-white ${n === color ? "outline outline-2 outline-gold" : "outline outline-1 outline-line"}`} style={{ background: c }} />)}</div></div>
            )}
            <div className="flex gap-3 items-center my-3.5">
              <span className="flex items-center gap-2 border border-line rounded-full px-2 py-1"><button onClick={() => setQty((q) => Math.max(1, q - 1))} className="w-[26px] h-[26px] rounded-full bg-sand border border-line">−</button><b>{qty}</b><button onClick={() => setQty((q) => Math.min(99, q + 1))} className="w-[26px] h-[26px] rounded-full bg-sand border border-line">+</button></span>
              <b className="text-clay">Total: {(p.now * qty).toLocaleString()}৳</b>
            </div>
            <div className="flex gap-2.5 flex-wrap">
              <button onClick={() => { addToCart(p, qty, variant); setCartOpen(true); }} className="flex-1 inline-flex justify-center items-center gap-2 bg-clay text-white rounded-[35px] px-5 py-3 text-[17px] font-bold hover:bg-clay-dark"><ShoppingCart size={16} />{t.addToCart}</button>
            </div>
            <div className="flex gap-2 flex-wrap my-3.5 text-base font-bold">
              <span className="inline-flex gap-1.5 items-center bg-paper border border-line rounded-full px-3 py-2"><Banknote size={14} />Cash on Delivery</span>
              <span className="inline-flex gap-1.5 items-center bg-paper border border-line rounded-full px-3 py-2"><Truck size={14} />Home Delivery All BD</span>
              <span className="inline-flex gap-1.5 items-center bg-paper border border-line rounded-full px-3 py-2"><RefreshCcw size={14} />Easy Exchange</span>
            </div>
          </div>
        </div>
        <ProductTabs description={p.description ?? ""} slug={p.slug} productName={p.name} />
        <h2 className="font-serif text-xl md:text-2xl my-3.5">{t.alsoLove} <span className="italic-accent">{t.love}</span></h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 md:gap-4 pb-10">
          {related.map((r) => (
            <ProductCard key={r.slug} product={r} />
          ))}
        </div>
      </main>
      <Footer />
      <FloatingWA />
      <CartDrawer />
    </>
  );
}

function ProductTabs({ description, slug, productName }: { description: string; slug: string; productName: string }) {
  const { t } = useLang();
  const [tab, setTab] = useState<"desc" | "rev">("desc");
  const [revCount, setRevCount] = useState<number | null>(null);
  return (
    <section className="my-6 max-w-3xl">
      <div className="flex gap-2 border-b border-line" role="tablist">
        {(["desc", "rev"] as const).map((k) => (
          <button
            key={k}
            role="tab"
            aria-selected={tab === k}
            onClick={() => setTab(k)}
            className={`px-5 py-2.5 text-[17px] font-bold -mb-px border-b-2 ${tab === k ? "border-clay text-clay" : "border-transparent text-muted"}`}
          >
            {k === "desc" ? t.descriptionTab : `${t.reviewsTab}${revCount ? ` (${revCount})` : ""}`}
          </button>
        ))}
      </div>
      <div className="py-4">
        {tab === "desc" ? (
          description ? (
            <div className="flex flex-col gap-2.5">
              {description.split(/\n+/).map((para, i) => (
                <p key={i} className="text-[17px] leading-relaxed">{para}</p>
              ))}
            </div>
          ) : (
            <p className="text-[16px] text-muted">{t.noDescription}</p>
          )
        ) : (
          <ProductReviews slug={slug} productName={productName} onCount={setRevCount} />
        )}
      </div>
    </section>
  );
}
