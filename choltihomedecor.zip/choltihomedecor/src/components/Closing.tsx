"use client";
import { MessageCircle, Phone, Mail, MapPin } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { WA_LINK } from "@/lib/data";
import { useLang } from "@/lib/lang";
import { useSettings, waLink, telLink } from "@/lib/settings-context";
import ChatWidget from "./ChatWidget";

export function CTA() {
  const { t } = useLang();
  const settings = useSettings();
  return (
    <div className="bg-cream py-[18px] pb-[58px]">
      <div className="max-w-[1180px] mx-auto px-5">
        <div className="rounded-[26px] p-5 md:p-[34px] flex justify-between items-center gap-4 md:gap-5 flex-wrap relative overflow-hidden bg-gradient-to-br from-forest-deep to-forest-2">
          <span className="absolute right-5 -top-2.5 text-[80px] text-white/15">✦</span>
          <div><h2 className="text-white text-lg md:text-2xl font-serif max-w-[520px]">{t.ctaTitle}</h2><p className="text-[#c8d7d2] text-sm md:text-base">{t.ctaSub}</p></div>
          <div className="flex gap-2 w-full md:w-auto">
            <a href={waLink(settings)} target="_blank" rel="noopener noreferrer" className="flex-[1.4] md:flex-none bg-white text-forest rounded-[35px] px-3 md:px-5 py-2.5 md:py-3 text-[14px] md:text-[17px] font-extrabold inline-flex justify-center gap-1.5 md:gap-2 items-center whitespace-nowrap min-w-0"><MessageCircle size={15} className="shrink-0" />WhatsApp {settings.hotline.replace(/\D/g, "").replace(/^880/, "0")}</a>
            <a href={telLink(settings)} className="flex-1 md:flex-none bg-white text-forest rounded-[35px] px-3 md:px-5 py-2.5 md:py-3 text-[14px] md:text-[17px] font-extrabold inline-flex justify-center gap-1.5 md:gap-2 items-center whitespace-nowrap min-w-0"><Phone size={15} className="shrink-0" />{t.callNow}</a>
          </div>
        </div>
      </div>
    </div>
  );
}

export function Footer() {
  const { lang } = useLang();
  const settings = useSettings();
  const address = lang === "bn" ? settings.address_bn : settings.address_en;
  return (
    <footer id="footer" className="bg-[#07382f] text-[#c7d4d0] py-[34px] scroll-mt-[170px]">
      <div className="max-w-[1180px] mx-auto px-5">
        <div className="grid md:grid-cols-3 gap-5">
          <div><div className="flex items-center gap-2.5 text-white"><Image src="/logo.png" alt="Cholti" width={120} height={40} className="h-14 w-auto rounded-lg object-cover" /></div><p className="text-[17px] mt-3">{lang === "bn" ? "প্রিমিয়াম হোম ডেকোর, সোফা কভার, বেডশিট, কুশন ও পর্দা।" : "Premium home decor, sofa cover, bedsheet, cushion and curtain."}</p></div>
          <div><b className="text-white">Quick Links</b><br /><br /><Link href="/" className="block">Home</Link><Link href="/shop" className="block">Shop</Link><Link href="/about" className="block">About</Link><Link href="/contact" className="block">Contact</Link><Link href="/track-order" className="block">Track Order</Link></div>
          <div><b className="text-white">Contact</b><br /><br /><a href={telLink(settings)} className="flex items-center gap-1.5"><Phone size={14} className="shrink-0" />Hotline: {settings.hotline}</a><a href={`mailto:${settings.email}`} className="flex items-center gap-1.5"><Mail size={14} className="shrink-0" />{settings.email}</a><span className="flex gap-1.5 mt-1.5 text-[17px]"><MapPin size={14} className="shrink-0 mt-0.5" />{address}</span><div className="flex gap-2 mt-3"><a href="https://www.facebook.com/Choltihomedecorbd" target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="w-9 h-9 rounded-full border border-white/20 grid place-items-center text-white"><svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" /></svg></a><a href={waLink(settings)} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="w-9 h-9 rounded-full border border-white/20 grid place-items-center text-white"><svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z" /></svg></a></div></div>
        </div>
        <div className="border-t border-white/10 mt-[22px] pt-4 flex justify-between flex-wrap gap-3 text-base"><span>© {new Date().getFullYear()} Cholti</span><span>Cash on Delivery • No advance needed</span></div>
      </div>
    </footer>
  );
}

export function FloatingWA() {
  return <ChatWidget />;
}

export { ChatWidget };
